package com.weighttrackingapp.entity;


import androidx.annotation.NonNull;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "users")
public class User {

    @PrimaryKey
    @NonNull // Primary keys must be non-null
    private String username;

    private String passwordHash;

    private double goalWeight;      // User's goal weight
    private String phoneNumber;     // SMS recipient
    private boolean smsEnabled;     // Track SMS preference

    // Constructor required by Room
    public User(@NonNull String username, String passwordHash) {
        this.username = username;
        this.passwordHash = passwordHash;
        // Initialize fields to safe defaults
        this.goalWeight = 0.0;
        this.phoneNumber = "";
        this.smsEnabled = false;
    }

    // Add Getters and Setters for the new fields:
    public double getGoalWeight() {
        return goalWeight;
    }

    public void setGoalWeight(double goalWeight) {
        this.goalWeight = goalWeight;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public boolean isSmsEnabled() {
        return smsEnabled;
    }

    public void setSmsEnabled(boolean smsEnabled) {
        this.smsEnabled = smsEnabled;
    }
    // Getters and Setters (required by Room)


    @NonNull
    public String getUsername() {
        return username;
    }

    public void setUsername(@NonNull String username) {
        this.username = username;
    }

    public String getPasswordHash() {
        return passwordHash;
    }

    public void setPasswordHash(String passwordHash) {
        this.passwordHash = passwordHash;
    }
}