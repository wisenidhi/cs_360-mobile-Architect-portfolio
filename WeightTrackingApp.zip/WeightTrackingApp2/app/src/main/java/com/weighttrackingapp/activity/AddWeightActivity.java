package com.weighttrackingapp.activity;

import androidx.appcompat.app.AppCompatActivity;
import android.app.DatePickerDialog;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.util.Log;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;
import java.util.concurrent.ExecutorService;

// IMPORTS FOR GOAL CHECK & SMS
import android.telephony.SmsManager;
import android.Manifest;
import androidx.core.content.ContextCompat;
import android.content.pm.PackageManager;

import com.weighttrackingapp.R;
import com.weighttrackingapp.entity.User;

// IMPORTS FOR Dao
import com.weighttrackingapp.dao.UserDao;
import com.weighttrackingapp.dao.WeightEntryDao;
import com.weighttrackingapp.databaseconfig.AppDatabase;
import com.weighttrackingapp.entity.WeightEntry;

import androidx.core.app.ActivityCompat;
import androidx.annotation.NonNull;


public class AddWeightActivity extends AppCompatActivity {

    private WeightEntryDao weightEntryDao;
    private UserDao userDao;
    private EditText weightEditText;
    private EditText dateEditText;
    private Button saveButton;

    private ExecutorService databaseExecutor;

    private String loggedInUsername;
    private Calendar selectedDateCalendar;

    // Field to store the ID of the entry being edited (-1 means new entry)
    private int entryIdToEdit = -1;

    // Constant for the Intent Extra Key used by WeightLogActivity
    private static final String ENTRY_ID_KEY = "ENTRY_ID";

    // FOR SMS RETRY LOGIC ---
    private static final int MY_PERMISSIONS_REQUEST_SEND_SMS = 101; // Unique request code
    private String smsRetryPhoneNumber; // To temporarily store phone number for retry
    private double smsRetryCurrentWeight; // To temporarily store weight for retry


    // KEYS FOR SMS RETRY LOGIC
    private static final String KEY_SMS_PHONE = "sms_phone_number";
    private static final String KEY_SMS_WEIGHT = "sms_current_weight";
    //
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_weight);

        // Initialize Database Access and Executor
        AppDatabase database = AppDatabase.getDatabase(getApplicationContext());
        weightEntryDao = database.weightEntryDao();
        userDao = database.userDao(); // Initialize UserDao
        databaseExecutor = AppDatabase.databaseWriteExecutor;

        dateEditText = findViewById(R.id.edit_text_date);
        weightEditText = findViewById(R.id.edit_text_today_weight);
        saveButton = findViewById(R.id.button_save_weight); // Initialize saveButton field

        // Initialize Calendar
        selectedDateCalendar = Calendar.getInstance();

        saveButton.setOnClickListener(v -> saveWeightEntry());
        dateEditText.setOnClickListener(v -> showDatePickerDialog());

        // Retrieve the username (Assume WeightLogActivity passes it)
        loggedInUsername = getIntent().getStringExtra("LOGGED_IN_USERNAME");

        // ====================================================================
        // CHECK FOR EDIT MODE
        // ====================================================================
        if (getIntent().hasExtra(ENTRY_ID_KEY)) {
            entryIdToEdit = getIntent().getIntExtra(ENTRY_ID_KEY, -1);
            if (entryIdToEdit != -1) {
                // If an ID is present, load the data on a background thread
                databaseExecutor.execute(() -> {
                    WeightEntry entry = weightEntryDao.getEntryById(entryIdToEdit);
                    if (entry != null) {
                        runOnUiThread(() -> prefillFields(entry));
                    }
                });
            }
        } else {
            // Set initial date display
            updateDateEditText();
        }

        // ERROR HANDLING
        if (loggedInUsername == null || loggedInUsername.isEmpty()) {
            Log.e("AddWeightActivity", "FATAL: No username found in intent. Cannot save weight.");
            Toast.makeText(this, "Error: User context missing. Please re-login.", Toast.LENGTH_LONG).show();
            finish();
        }

        if (savedInstanceState != null) {
            smsRetryPhoneNumber = savedInstanceState.getString(KEY_SMS_PHONE, null);
            smsRetryCurrentWeight = savedInstanceState.getDouble(KEY_SMS_WEIGHT, 0.0);
        }
    }

    /**
     * Pre-fills the UI fields with data from an existing WeightEntry for editing.
     */
    private void prefillFields(WeightEntry entry) {
        // Pre-fill Weight
        weightEditText.setText(String.format(Locale.getDefault(), "%.1f", entry.getWeight()));

        // Pre-fill Date
        selectedDateCalendar.setTimeInMillis(entry.getDate());
        updateDateEditText();

        // Change button text to reflect update action
        saveButton.setText("Update Weight");
        Toast.makeText(this, "Editing entry for: " + dateEditText.getText(), Toast.LENGTH_SHORT).show();
    }

    /**
     * Sends the goal-reached notification via SMS.
     */
    public void sendGoalReachedSms(String phoneNumber, double currentWeight) {
        // 1. Check SMS permission status
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {

            // --- SAVE DATA FOR RETRY ---
            smsRetryPhoneNumber = phoneNumber;
            smsRetryCurrentWeight = currentWeight;

            // 2. Permission is NOT granted. Request it from the user.
            // The result will be handled in the Activity's onRequestPermissionsResult method.
            ActivityCompat.requestPermissions(
                    this,
                    new String[]{Manifest.permission.SEND_SMS},
                    MY_PERMISSIONS_REQUEST_SEND_SMS
            );

            // Stop here; the SMS will be sent ONLY after the user grants permission
            // in the Activity's onRequestPermissionsResult callback.
            return;
        }

        // 3. Permission IS granted, proceed with sending the SMS
        try {
            String message = String.format(
                    "Goal Reached Alert! Your latest weight (%.1f lbs) meets or beats your goal!",
                    currentWeight
            );

            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(phoneNumber, null, message, null, null);
            runOnUiThread(() -> Toast.makeText(this, "Goal alert SENT to " + phoneNumber, Toast.LENGTH_LONG).show());

        } catch (Exception e) {
            runOnUiThread(() -> Toast.makeText(this, "SMS failed to send. Check number format.", Toast.LENGTH_LONG).show());
            Log.e("AddWeightActivity", "SMS Send Error: " + e.getMessage());
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == MY_PERMISSIONS_REQUEST_SEND_SMS) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Permission was granted, now retry sending the SMS!

                // Use the stored member variables for the retry attempt
                if (smsRetryPhoneNumber != null && !smsRetryPhoneNumber.isEmpty()) {
                    sendGoalReachedSms(smsRetryPhoneNumber, smsRetryCurrentWeight);
                } else {
                    Log.e("AddWeightActivity", "SMS Retry failed: Phone number was null or empty.");
                    Toast.makeText(this, "SMS retry failed: Phone number missing.", Toast.LENGTH_LONG).show();
                }

            } else {
                // Permission was denied. Inform the user.
                Toast.makeText(this, "SMS Permission denied. Goal alert cannot be sent.", Toast.LENGTH_LONG).show();
            }
        }
    }

    /**
     * Shows the Date Picker Dialog when the date field is clicked.
     */
    private void showDatePickerDialog() {
        DatePickerDialog.OnDateSetListener dateSetListener = (view, year, month, dayOfMonth) -> {
            // Update the Calendar instance with the new date
            selectedDateCalendar.set(Calendar.YEAR, year);
            selectedDateCalendar.set(Calendar.MONTH, month);
            selectedDateCalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);

            // Crucial: Clear time fields to ensure midnight (00:00:00) timestamp
            selectedDateCalendar.set(Calendar.HOUR_OF_DAY, 0);
            selectedDateCalendar.set(Calendar.MINUTE, 0);
            selectedDateCalendar.set(Calendar.SECOND, 0);
            selectedDateCalendar.set(Calendar.MILLISECOND, 0);

            updateDateEditText();
        };

        new DatePickerDialog(
                AddWeightActivity.this,
                dateSetListener,
                selectedDateCalendar.get(Calendar.YEAR),
                selectedDateCalendar.get(Calendar.MONTH),
                selectedDateCalendar.get(Calendar.DAY_OF_MONTH)
        ).show();
    }

    /**
     * Updates the date EditText with the currently selected date.
     */
    private void updateDateEditText() {
        String dateFormat = "yyyy-MM-dd";
        SimpleDateFormat sdf = new SimpleDateFormat(dateFormat, Locale.getDefault());
        dateEditText.setText(sdf.format(selectedDateCalendar.getTime()));
    }

    @Override
    protected void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        // Only save the data if a permission request is pending
        if (smsRetryPhoneNumber != null && !smsRetryPhoneNumber.isEmpty()) {
            outState.putString(KEY_SMS_PHONE, smsRetryPhoneNumber);
            outState.putDouble(KEY_SMS_WEIGHT, smsRetryCurrentWeight);
        }
    }

    /**
     * Handles saving (Insert or Update) of the weight entry.
     */
    private void saveWeightEntry() {
        String weightText = weightEditText.getText().toString();

        if (weightText.isEmpty()) {
            Toast.makeText(this, "Please enter a weight value.", Toast.LENGTH_SHORT).show();
            return;
        }

        double weightValue;
        try {
            weightValue = Double.parseDouble(weightText);
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Please enter a valid number.", Toast.LENGTH_SHORT).show();
            return;
        }

        if (weightValue <= 0) {
            Toast.makeText(this, "Weight must be greater than zero.", Toast.LENGTH_SHORT).show();
            return;
        }

        // Use background thread for all DB operations
        databaseExecutor.execute(() -> {
            String toastMessage;

            if (entryIdToEdit == -1) {
                // ======================================
                // 1. CREATE (INSERT) OPERATION
                // ======================================
                final WeightEntry newEntry = new WeightEntry(
                        selectedDateCalendar.getTimeInMillis(),
                        weightValue,
                        loggedInUsername
                );
                weightEntryDao.insert(newEntry);
                toastMessage = "Weight saved!";

            } else {

                // UPDATE OPERATION
                // Fetch the existing entry to preserve the original ID and metadata
                WeightEntry existingEntry = weightEntryDao.getEntryById(entryIdToEdit);

                if (existingEntry != null) {
                    // Update its fields
                    existingEntry.setWeight(weightValue);
                    existingEntry.setDate(selectedDateCalendar.getTimeInMillis());

                    weightEntryDao.update(existingEntry); // CALL UPDATE
                    toastMessage = "Weight updated!";
                } else {
                    toastMessage = "Error: Entry not found for update.";
                }
            }


            // GOAL CHECK (Applies to both Insert and Update)
            if (toastMessage.contains("Weight saved") || toastMessage.contains("Weight updated")) {
                User user = userDao.getUserByUsername(loggedInUsername);

                // Perform Goal Check
                if (user != null && user.getGoalWeight() > 0) {
                    if (weightValue <= user.getGoalWeight()) {

                        // Send goal reached notification
                        runOnUiThread(() -> Toast.makeText(AddWeightActivity.this, "GOAL REACHED! Congratulations!", Toast.LENGTH_LONG).show());

                        // Send SMS if enabled
                        if (user.isSmsEnabled() && !user.getPhoneNumber().isEmpty()) {
                            sendGoalReachedSms(user.getPhoneNumber(), weightValue);
                        }
                    }
                }
            }


            // Finalize the transaction
            final String finalToastMessage = toastMessage;
            runOnUiThread(() -> {
                Toast.makeText(AddWeightActivity.this, finalToastMessage, Toast.LENGTH_SHORT).show();
                finish(); // Close the current activity
            });
        });
    }
}