package com.weighttrackingapp.databaseconfig;


import android.content.Context;
import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;

import com.weighttrackingapp.entity.User;
import com.weighttrackingapp.dao.UserDao;
import com.weighttrackingapp.entity.WeightEntry;
import com.weighttrackingapp.dao.WeightEntryDao;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

// Version is 4 because we include User and WeightEntry entities
@Database(entities = {WeightEntry.class, User.class}, version = 4, exportSchema = false)
public abstract class AppDatabase extends RoomDatabase {

    public abstract WeightEntryDao weightEntryDao();
    public abstract UserDao userDao();

    // The singleton instance
    private static volatile AppDatabase INSTANCE;

    // ExecutorService for running database operations on a background thread
    private static final int NUMBER_OF_THREADS = 4;
    public static final ExecutorService databaseWriteExecutor =
            Executors.newFixedThreadPool(NUMBER_OF_THREADS);

    public static AppDatabase getDatabase(final Context context) {
        if (INSTANCE == null) {
            synchronized (AppDatabase.class) {
                if (INSTANCE == null) {
                    INSTANCE = Room.databaseBuilder(context.getApplicationContext(),
                                    AppDatabase.class, "weight_tracker_db")
                            // Added for schema changes during development
                            .fallbackToDestructiveMigration()
                            .build();
                }
            }
        }
        return INSTANCE;
    }
}