
package com.weighttrackingapp.activity;


import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

import com.weighttrackingapp.R;
import com.weighttrackingapp.entity.User;
import com.weighttrackingapp.dao.UserDao;
import com.weighttrackingapp.databaseconfig.AppDatabase;

import java.util.concurrent.ExecutorService;

public class GoalActivity extends AppCompatActivity {


    // UI Elements
    private EditText goalWeightEditText;
    private EditText phoneNumberEditText;
    private CheckBox enableSmsCheckbox;
    private Button saveGoalButton;

    // Database and User data
    private UserDao userDao;
    private ExecutorService databaseExecutor;
    private String loggedInUsername;
    private User currentUser; // To hold the user data when loaded

    // Permission Launcher
    private ActivityResultLauncher<String> requestPermissionLauncher;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_goal);

        // Initialize DB and Views
        AppDatabase database = AppDatabase.getDatabase(getApplicationContext());
        userDao = database.userDao();
        // Use the existing executor from AppDatabase
        databaseExecutor = AppDatabase.databaseWriteExecutor;

        goalWeightEditText = findViewById(R.id.edit_text_goal_weight); // Ensure these IDs exist in XML
        phoneNumberEditText = findViewById(R.id.edit_text_phone_number);
        enableSmsCheckbox = findViewById(R.id.checkbox_enable_sms);
        saveGoalButton = findViewById(R.id.button_save_goal);

        // Get Username and Load Current Goal
        loggedInUsername = getIntent().getStringExtra("LOGGED_IN_USERNAME");
        if (loggedInUsername == null || loggedInUsername.isEmpty()) {
            Toast.makeText(this, "Error: User context missing.", Toast.LENGTH_LONG).show();
            finish();
            return;
        }
        loadCurrentGoal(); // Load data asynchronously

        //  Initialize Permission Handler
        requestPermissionLauncher = registerForActivityResult(
                new ActivityResultContracts.RequestPermission(),
                isGranted -> {
                    if (isGranted) {
                        Toast.makeText(this, "SMS permission granted.", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(this, "SMS permission denied. Cannot send alerts.", Toast.LENGTH_LONG).show();
                        enableSmsCheckbox.setChecked(false); // Uncheck if denied
                    }
                }
        );

        // Set Listeners
        saveGoalButton.setOnClickListener(v -> saveGoal());
        enableSmsCheckbox.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked && !checkSmsPermissionStatus()) {
                requestSmsPermission();
            }
        });
    }

    /** Loads the current user's goal data from the database. */
    private void loadCurrentGoal() {
        databaseExecutor.execute(() -> {
            // Retrieve User data (must be done on background thread)
            currentUser = userDao.getUserByUsername(loggedInUsername);

            if (currentUser != null) {
                runOnUiThread(() -> {
                    // Update UI on main thread
                    if (currentUser.getGoalWeight() > 0) {
                        goalWeightEditText.setText(String.valueOf(currentUser.getGoalWeight()));
                    }
                    phoneNumberEditText.setText(currentUser.getPhoneNumber());
                    enableSmsCheckbox.setChecked(currentUser.isSmsEnabled());
                });
            }
        });
    }

    /** Saves the new goal data to the database. */
    private void saveGoal() {
        String weightText = goalWeightEditText.getText().toString();
        String phoneNumber = phoneNumberEditText.getText().toString().trim();
        boolean smsEnabled = enableSmsCheckbox.isChecked();

        if (weightText.isEmpty()) {
            Toast.makeText(this, "Please enter a goal weight.", Toast.LENGTH_SHORT).show();
            return;
        }

        double goalWeight;
        try {
            goalWeight = Double.parseDouble(weightText);
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Please enter a valid number for goal weight.", Toast.LENGTH_SHORT).show();
            return;
        }

        // Final validation
        if (smsEnabled && phoneNumber.isEmpty()) {
            Toast.makeText(this, "Please enter a phone number to enable SMS.", Toast.LENGTH_SHORT).show();
            enableSmsCheckbox.setChecked(false);
            return;
        }

        // Save on background thread
        databaseExecutor.execute(() -> {
            // Use the loaded User object (currentUser) and update its fields
            if (currentUser != null) {
                currentUser.setGoalWeight(goalWeight);
                currentUser.setPhoneNumber(phoneNumber);
                currentUser.setSmsEnabled(smsEnabled);

                userDao.updateUser(currentUser); // Use the new update method

                runOnUiThread(() -> {
                    Toast.makeText(GoalActivity.this, "Goal Saved Successfully!", Toast.LENGTH_SHORT).show();
                    finish();
                });
            }
        });
    }

    /** Checks if the app currently has SMS permission. */
    private boolean checkSmsPermissionStatus() {
        return ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED;
    }

    /** Requests the SMS permission. */
    private void requestSmsPermission() {
        requestPermissionLauncher.launch(Manifest.permission.SEND_SMS);
    }

}