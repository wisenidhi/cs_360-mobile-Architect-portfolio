package com.weighttrackingapp.activity;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.weighttrackingapp.R;
import com.weighttrackingapp.entity.User;
import com.weighttrackingapp.dao.UserDao;
import com.weighttrackingapp.databaseconfig.AppDatabase;

import java.util.concurrent.ExecutorService;

public class MainActivity extends AppCompatActivity {

    private UserDao userDao;
    private EditText emailEditText;
    private EditText passwordEditText;
    private Button signInButton;
    private Button createAccountButton;
    private ExecutorService databaseExecutor;
    private Handler mainHandler; // To post results back to the main thread

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize DAO and Executor
        AppDatabase database = AppDatabase.getDatabase(getApplicationContext());
        userDao = database.userDao();
        databaseExecutor = AppDatabase.databaseWriteExecutor;
        mainHandler = new Handler(Looper.getMainLooper());

        // Bind Views
        emailEditText = findViewById(R.id.edit_text_email);
        passwordEditText = findViewById(R.id.edit_text_password);
        signInButton = findViewById(R.id.button_sign_in);
        createAccountButton = findViewById(R.id.button_create_account);

        // Set up Listeners
        signInButton.setOnClickListener(v -> attemptLogin());
        createAccountButton.setOnClickListener(v -> attemptRegistration());
    }

    private void attemptLogin() {
        final String username = emailEditText.getText().toString().trim();
        final String password = passwordEditText.getText().toString();

        if (username.isEmpty() || password.isEmpty()) {
            showToast("Please enter both email and password.");
            return;
        }

        // Run login check on background thread
        databaseExecutor.execute(() -> {
            final User user = userDao.getUserByUsername(username);

            mainHandler.post(() -> {
                if (user != null && user.getPasswordHash().equals(password)) {
                    showToast("Login Successful! Welcome, " + username + ".");
                    navigateToWeightLog(username); // MODIFIED call
                } else {
                    showToast("Login Failed. Invalid username or password.");
                }
            });
        });
    }

    private void attemptRegistration() {
        final String username = emailEditText.getText().toString().trim();
        final String password = passwordEditText.getText().toString();

        if (username.isEmpty() || password.isEmpty()) {
            showToast("Please fill out all fields to register.");
            return;
        }

        final User newUser = new User(username, password);

        // Run registration on background thread
        databaseExecutor.execute(() -> {
            try {
                userDao.registerUser(newUser);

                mainHandler.post(() -> {
                    showToast("Account created successfully! You are now logged in.");
                    navigateToWeightLog(username); // MODIFIED call
                });
            } catch (Exception e) {
                // Catches error if username already exists
                mainHandler.post(() -> showToast("Registration Failed: User with that email already exists."));
            }
        });
    }

    private void navigateToWeightLog(String loggedInUsername) {
        Intent intent = new Intent(this, WeightLogActivity.class);

        // PASS THE USERNAME AS AN EXTRA
        intent.putExtra("LOGGED_IN_USERNAME", loggedInUsername);

        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        finish();
    }

    private void showToast(String message) {
        Toast.makeText(MainActivity.this, message, Toast.LENGTH_LONG).show();
    }
}