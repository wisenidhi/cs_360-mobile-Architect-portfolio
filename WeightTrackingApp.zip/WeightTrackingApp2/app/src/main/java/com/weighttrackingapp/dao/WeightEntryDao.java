package com.weighttrackingapp.dao;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Update;

import com.weighttrackingapp.entity.WeightEntry;

import java.util.List;

@Dao
public interface WeightEntryDao {

    // Create (Insert) - Must be called from a background thread
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insert(WeightEntry entry);


    // Update - Must be called from a background thread
    @Update
    void update(WeightEntry entry);

    // Read (Get by ID)
    @Query("SELECT * FROM weight_entries WHERE id = :id LIMIT 1")
    WeightEntry getEntryById(int id);


    // Delete - Must be called from a background thread
    @Delete
    void delete(WeightEntry entry);

    @Query("SELECT * FROM weight_entries WHERE username = :username ORDER BY date DESC")
    LiveData<List<WeightEntry>> getAllEntries(String username); // MODIFIED to accept username

    /**
     * Retrieves a single WeightEntry for a specific user and date.
     * The date is queried using a range (start of day to end of day).
     * @param username The logged-in user's username.
     * @param startOfDayMillis The timestamp for 00:00:00 of the target day.
     * @param endOfDayMillis The timestamp for 23:59:59 of the target day.
     * @return LiveData containing the matching WeightEntry, or null if none is found.
     */
    @Query("SELECT * FROM weight_entries WHERE username = :username AND date >= :startOfDayMillis AND date <= :endOfDayMillis LIMIT 1")
    LiveData<WeightEntry> getEntryForDate(String username, long startOfDayMillis, long endOfDayMillis);

}