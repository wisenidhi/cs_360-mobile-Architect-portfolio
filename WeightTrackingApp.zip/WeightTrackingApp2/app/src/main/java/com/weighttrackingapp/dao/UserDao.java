package com.weighttrackingapp.dao;


import androidx.room.Dao;
import androidx.room.Insert;
//import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Update;
import androidx.lifecycle.LiveData;

import com.weighttrackingapp.entity.User;

@Dao
public interface UserDao {

    // Create (Register) - Must be called from a background thread
    @Insert
    void registerUser(User user);

    // Read (Login Check) - Must be called from a background thread
    @Query("SELECT * FROM users WHERE username = :username")
    User getUserByUsername(String username);

    @Update
    void updateUser(User user);

    @Query("SELECT * FROM users WHERE username = :username LIMIT 1")
    LiveData<User> getUserByUsernameLiveData(String username);
}