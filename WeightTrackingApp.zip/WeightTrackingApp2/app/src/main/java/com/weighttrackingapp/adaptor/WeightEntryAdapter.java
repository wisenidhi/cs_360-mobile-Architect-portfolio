package com.weighttrackingapp.adaptor;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.ListAdapter;
import androidx.recyclerview.widget.RecyclerView;

import com.weighttrackingapp.R;
import com.weighttrackingapp.entity.WeightEntry;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class WeightEntryAdapter extends ListAdapter<WeightEntry, WeightEntryAdapter.WeightEntryViewHolder> {

    // 1. Interface for DELETE click handling
    public interface OnDeleteClickListener {
        void onDeleteClick(WeightEntry entry);
    }

    // 2. Interface for ITEM (EDIT) click handling
    public interface OnItemClickListener {
        void onItemClick(WeightEntry entry);
    }

    private final OnDeleteClickListener deleteListener;
    private final OnItemClickListener itemClickListener; // NEW FIELD
    private final SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());

    // 3. CONSTRUCTOR to accept both listeners
    public WeightEntryAdapter(@NonNull DiffUtil.ItemCallback<WeightEntry> diffCallback,
                              OnDeleteClickListener deleteListener,
                              OnItemClickListener itemClickListener) {
        super(diffCallback);
        this.deleteListener = deleteListener;
        this.itemClickListener = itemClickListener;
    }

    @NonNull
    @Override
    public WeightEntryViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_weight_entry, parent, false);
        return new WeightEntryViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull WeightEntryViewHolder holder, int position) {
        WeightEntry current = getItem(position);
        holder.bind(current);
    }

    // ViewHolder class
    class WeightEntryViewHolder extends RecyclerView.ViewHolder {
        private final TextView dateTextView;
        private final TextView weightTextView;
        private final ImageButton deleteButton;

        public WeightEntryViewHolder(View itemView) {
            super(itemView);
            dateTextView = itemView.findViewById(R.id.text_date);
            weightTextView = itemView.findViewById(R.id.text_weight);
            deleteButton = itemView.findViewById(R.id.button_delete_entry);
        }

        public void bind(WeightEntry entry) {
            // Display date
            dateTextView.setText(dateFormat.format(new Date(entry.getDate())));

            // Display weight (formatted to one decimal place)
            // Assuming your unit is 'kg' based on the existing code.
            weightTextView.setText(String.format(Locale.getDefault(), "%.1f lbs", entry.getWeight()));

            // Attach the delete listener
            deleteButton.setOnClickListener(v -> deleteListener.onDeleteClick(entry));

            // 4. NEW: Attach the item click listener for editing
            itemView.setOnClickListener(v -> itemClickListener.onItemClick(entry));
        }
    }

    // DiffUtil implementation for efficient list updates (Remains the same)
    public static class WeightEntryDiff extends DiffUtil.ItemCallback<WeightEntry> {
        @Override
        public boolean areItemsTheSame(@NonNull WeightEntry oldItem, @NonNull WeightEntry newItem) {
            return oldItem.getId() == newItem.getId();
        }

        @Override
        public boolean areContentsTheSame(@NonNull WeightEntry oldItem, @NonNull WeightEntry newItem) {
            return oldItem.getWeight() == newItem.getWeight() && oldItem.getDate() == newItem.getDate();
        }
    }
}