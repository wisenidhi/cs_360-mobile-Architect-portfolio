package com.weighttrackingapp.entity;

import androidx.room.Entity;
import androidx.room.PrimaryKey;
import androidx.annotation.NonNull;

@Entity(tableName = "weight_entries")
public class WeightEntry {

    // autoGenerate = true makes the ID unique and self-incrementing
    @PrimaryKey(autoGenerate = true)
    private int id;

    // Using Long to store the date as a Unix timestamp
    private long date;

    private double weight;

    @NonNull // Required by Room
    private String username;

    // Constructor required by Room
    public WeightEntry(long date, double weight, @NonNull String username) {
        this.date = date;
        this.weight = weight;
        this.username = username;
    }

    // Getters and Setters (required by Room)

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public long getDate() {
        return date;
    }

    public void setDate(long date) {
        this.date = date;
    }

    public double getWeight() {
        return weight;
    }

    public void setWeight(double weight) {
        this.weight = weight;
    }

    @NonNull
    public String getUsername() {
        return username;
    }

    public void setUsername(@NonNull String username) {
        this.username = username;
    }
}
