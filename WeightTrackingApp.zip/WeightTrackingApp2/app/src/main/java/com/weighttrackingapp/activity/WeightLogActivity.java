package com.weighttrackingapp.activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.LinearLayoutManager;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageButton;
import android.widget.TextView;
import android.util.Log;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.weighttrackingapp.R;
import com.weighttrackingapp.dao.UserDao;
import com.weighttrackingapp.adaptor.WeightEntryAdapter;
import com.weighttrackingapp.dao.WeightEntryDao;
import com.weighttrackingapp.databaseconfig.AppDatabase;
import com.weighttrackingapp.entity.WeightEntry;

import java.util.concurrent.ExecutorService;
import android.widget.Toast;
import java.util.Locale;


public class WeightLogActivity extends AppCompatActivity {

    private WeightEntryDao weightEntryDao;
    private UserDao userDao;
    private WeightEntryAdapter adapter;
    private ExecutorService databaseExecutor;

    private String loggedInUsername;

    private TextView statusBannerTextView;

    //  variables to hold the current values for banner update
    private Double currentLatestWeight = 0.0;
    private Double currentGoalWeight = 0.0;

    // Constant for the Intent Extra Key
    private static final String ENTRY_ID_KEY = "ENTRY_ID";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_weight_log);

        // Username check
        loggedInUsername = getIntent().getStringExtra("LOGGED_IN_USERNAME");
        if (loggedInUsername == null || loggedInUsername.isEmpty()) {
            Log.e("WeightLogActivity", "FATAL: No username found. Redirecting to login.");
            Toast.makeText(this, "Session expired. Please log in.", Toast.LENGTH_LONG).show();
            Intent intent = new Intent(WeightLogActivity.this, MainActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            finish();
            return;
        }


        // Initialize Database Access and Executor
        AppDatabase database = AppDatabase.getDatabase(getApplicationContext());
        weightEntryDao = database.weightEntryDao();
        userDao = database.userDao();
        databaseExecutor = AppDatabase.databaseWriteExecutor;

        // Setup UI elements
        RecyclerView recyclerView = findViewById(R.id.recycler_view_weights);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Find the TextViews we need to update
        statusBannerTextView = findViewById(R.id.text_login_reminder);

        // Adapter initialization
        adapter = new WeightEntryAdapter(
                new WeightEntryAdapter.WeightEntryDiff(),

                //  OnDeleteClickListener with Method Reference
                this::deleteWeightEntry,

                //OnItemClickListener with Lambda Expression
                (entry) -> {
                    Intent intent = new Intent(WeightLogActivity.this, AddWeightActivity.class);
                    intent.putExtra("LOGGED_IN_USERNAME", loggedInUsername);
                    intent.putExtra(ENTRY_ID_KEY, entry.getId());
                    startActivity(intent);
                }
        );
        recyclerView.setAdapter(adapter);

        // Observe LiveData for the entire list (for RecyclerView and Latest Weight in Banner)
        weightEntryDao.getAllEntries(loggedInUsername).observe(this, weightEntries -> {
            adapter.submitList(weightEntries);
            //  Update the banner with the latest entry's weight
            if (weightEntries != null && !weightEntries.isEmpty()) {
                updateStatusBanner(weightEntries.get(0).getWeight(), null);
            } else {
                updateStatusBanner(0.0, null);
            }
        });

        // Observe LiveData for the GOAL
        userDao.getUserByUsernameLiveData(loggedInUsername).observe(this, user -> {
            if (user != null) {
                updateStatusBanner(null, user.getGoalWeight());
            }
        });



        // Navigation/Create Hook (Floating Action Button)
        FloatingActionButton fabAddWeight = findViewById(R.id.fab_add_weight);
        fabAddWeight.setOnClickListener(v -> {
            // Launch AddWeightActivity (Create action)
            Intent intent = new Intent(WeightLogActivity.this, AddWeightActivity.class);
            // Pass the username
            intent.putExtra("LOGGED_IN_USERNAME", loggedInUsername);
            startActivity(intent);
        });

        // Navigation to Goal Screen (ImageButton)
        ImageButton setGoalButton = findViewById(R.id.button_goal);
        setGoalButton.setOnClickListener(v -> {
            Intent intent = new Intent(WeightLogActivity.this, GoalActivity.class);
            intent.putExtra("LOGGED_IN_USERNAME", loggedInUsername);
            startActivity(intent);
        });

        // Sign Out Hook
        ImageButton signOutButton = findViewById(R.id.button_sign_out);
        signOutButton.setOnClickListener(v -> {
            Toast.makeText(WeightLogActivity.this, "Signing out...", Toast.LENGTH_SHORT).show();

            Intent intent = new Intent(WeightLogActivity.this, MainActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            finish();
        });
    }


    /**
     * Helper method to update the status banner with the latest weight and current goal.
     */
    private void updateStatusBanner(Double latestWeight, Double goalWeight) {
        if (latestWeight != null) {
            currentLatestWeight = latestWeight;
        }
        if (goalWeight != null) {
            currentGoalWeight = goalWeight;
        }

        String latestText = currentLatestWeight > 0 ?
                String.format(Locale.getDefault(), "%.1f lbs", currentLatestWeight) :
                "--";

        String goalText = currentGoalWeight > 0 ?
                String.format(Locale.getDefault(), "%.1f lbs", currentGoalWeight) :
                "--";

        // Note: The text here should now reflect the "Most recent weight" update you requested previously.
        String bannerText = "Current weight: " + latestText + " | Goal: " + goalText;
        statusBannerTextView.setText(bannerText);
    }

    /**
     * Delete Operation implementation
     */
    private void deleteWeightEntry(final WeightEntry entry) {
        databaseExecutor.execute(() -> weightEntryDao.delete(entry));
    }

}