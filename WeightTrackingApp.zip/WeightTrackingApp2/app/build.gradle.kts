plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
    alias(libs.plugins.kotlin.compose)
}

android {
    namespace = "com.weighttrackingapp"

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_1_8 // Changed from 11 for better compatibility
        targetCompatibility = JavaVersion.VERSION_1_8 // Changed from 11 for better compatibility
    }
    kotlinOptions {
        // Must match compileOptions target
        jvmTarget = "1.8" // Changed from 11
    }
    compileSdk {
        version = release(36)
    }

    defaultConfig {
        applicationId = "com.weighttrackingapp"
        minSdk = 34
        targetSdk = 36
        versionCode = 1
        versionName = "1.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_11
        targetCompatibility = JavaVersion.VERSION_11
    }
    kotlinOptions {
        jvmTarget = "11"
    }
    buildFeatures {
        compose = true
    }
}

dependencies {
    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.lifecycle.runtime.ktx)

    //  Database (Room) and Lifecycle Dependencies ---

    val roomVersion = "2.6.1"
    val lifecycleVersion = "2.7.0"
    val recyclerViewVersion = "1.4.0"

    // 1. Room Core Library (import androidx.room.Entity)
    implementation("androidx.room:room-runtime:$roomVersion")

    annotationProcessor("androidx.room:room-compiler:$roomVersion")

    // 3. LiveData & ViewModel (Used in WeightEntryDao and WeightLogActivity)
    implementation("androidx.lifecycle:lifecycle-livedata:$lifecycleVersion")
    implementation("androidx.lifecycle:lifecycle-viewmodel:$lifecycleVersion")
    implementation("androidx.lifecycle:lifecycle-runtime:${lifecycleVersion}")


    // 4. RecyclerView (For the grid display in WeightLogActivity)
    implementation("androidx.recyclerview:recyclerview:$recyclerViewVersion")

    // --- END: Database (Room) and Lifecycle Dependencies ---

    implementation("androidx.constraintlayout:constraintlayout:2.2.1")
    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.lifecycle.runtime.ktx)
    implementation(libs.androidx.activity.compose)
    implementation(platform(libs.androidx.compose.bom))
    implementation(libs.androidx.compose.ui)
    implementation(libs.androidx.compose.ui.graphics)
    implementation(libs.androidx.compose.ui.tooling.preview)
    implementation(libs.androidx.compose.material3)


// LINE FOR MATERIAL STYLES (Fixes: Cannot resolve symbol '@style/...' and '?attr/...')
    implementation("com.google.android.material:material:1.13.0")
// appcompat library
    implementation("androidx.appcompat:appcompat:1.6.1")

    testImplementation(libs.junit)
    androidTestImplementation(libs.androidx.junit)
    androidTestImplementation(libs.androidx.espresso.core)
    androidTestImplementation(platform(libs.androidx.compose.bom))
    androidTestImplementation(libs.androidx.compose.ui.test.junit4)
    debugImplementation(libs.androidx.compose.ui.tooling)
    debugImplementation(libs.androidx.compose.ui.test.manifest)
}